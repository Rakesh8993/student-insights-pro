import pytest
from src.pipeline import DEFAULT_FEATURES,TARGET,build_pipeline,evaluate_model,make_demo_data,split_xy

def test_demo_data_columns():
    data=make_demo_data(100); assert TARGET in data and set(DEFAULT_FEATURES).issubset(data.columns); assert len(data)==100

def test_pipeline_trains():
    data=make_demo_data(120); _,x,y=split_xy(data,TARGET,DEFAULT_FEATURES); model=build_pipeline(x); model.fit(x,y); assert len(model.predict(x.iloc[:5]))==5

def test_reject_target_as_feature():
    with pytest.raises(ValueError): split_xy(make_demo_data(30),TARGET,[TARGET])

def test_metrics():
    result=evaluate_model([10,20,30],[12,18,29]); assert result['mae']>=0 and result['rmse']>=0
